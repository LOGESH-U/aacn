<link rel="stylesheet" href="../css/rulesAndRegulation.css">
<link rel="stylesheet" href="../css/authority.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">


<?php  
require_once('./php_files/top_header.php');
require_once('./php_files/nav_header.php');
 ?>

 <div class="bg">


<div class="authority">
        <div class="heading">constitution of authority</div>
        <div class="msg">In exercise of the  of the powers conferred under section 45 and in pursuance of the provisions contained under sub-section (1) and (2) of Section 46 of Mental Healthcare Act, 2017, the Governor of Tamil Nadu, constitute an authority called Tamil Nadu State Mental Health Authority and it consists of chairperson and  members, as follows:</div>
    <div class="authority_table">
        <table class="table table-bordered ">
            <thead>
                <tr>
                <th scope="col">No</th>
                <th scope="col">Designation/Position</th>
                <th scope="col">Position In Authority</th>
                <th scope="col">Sec</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>1</td>
                <td>principal secretary to government in the department of health state government</td>
                <td>chairperson-ex-officio</td>
                <td>46(a)</td>
                </tr>
                <tr>
                <td>2</td>
                <td>joint secretary in the department of health of state in charge of mental health</td>
                <td>member-ex-officio</td>
                <td>46(b)</td>
                </tr>
                <tr>
                <td>3</td>
                <td>director of medical education</td>
                <td>member-ex-officio</td>
                <td>46(c)</td>
                </tr>
                <td>4</td>
                <td>join secretary to government, social welfare & Nutritious meal programme department</td>
                <td>member-ex-officio</td>
                <td>56(d)</td>
                </tr>
                </tr>
                <td>5</td>
                <td>director of mental and rural health services</td>
                <td>member-ex-officio</td>
                <td>45(e)</td>
                </tr>
                </tr>
                <td>6</td>
                <td>mission director,national health mission/state health society</td>
                <td>member-ex-officio</td>
                <td>46(e)</td>
                </tr>
                </tr>
                <td>7</td>
                <td>state commissioner for welfare of differently abeld person</td>
                <td>member-ex-officio</td>
                <td>46(e)</td>
                </tr>
                <tr>
                <td>8</td>
               <td>managing director, tamilnadu woman development corporation</td>
                <td>member-ex-officio</td>
                <td>46(e)</td>
                </tr>
               <tr>
               <td>9</td>
                <td>state nodal officer, district mental health programme</td>
                <td>member-ex-officio</td>
                <td>46(f)</td>
               </tr>
               <tr>
               <td>10</td>
                <td>director, institute of mental health</td>
                <td>member-ex-officio</td>
                <td>46(f)</td>
               </tr>
               <tr>
               <td>11</td>
               <td>dr.w.j.alaxander gnanadurai, head of the department, dept. of psychiatry, government stanley medical collage, chennai</td>
                <td>member</td>
                <td>46(f)</td>
               </tr>
               <tr>
                   <td>12</td>
                   <td>eminent psychiatrist: dr.s.rajarathinam, retired, professor & head of psychiatry, government stanley medical collage, chennai</td>
                   <td>member</td>
                   <td>46(g)</td>
               </tr>
               <tr>
                   <td>13</td>
                   <td>mental health professional as defined in item (iii) of clause (r) of ub-section(1) of section 2 of mental healthcare act, 2017</td>
                   <td>member eligible person</td>
                   <td>46(h)</td>
               </tr>
               <tr>
                   <td>14</td>
                   <td>psychiatric social worker: thiru.d.kotteswara rao, assistant director, clinical psychologist at institute of mental health, chennai</td>
                   <td>member</td>
                   <td>46(i)</td>
               </tr>
               <tr>
                   <td>15</td>
                   <td>clinical psychologist: thiru.k.vijayam, formally assistant professor clinical psychologist at institute of mental health, chennai-19</td>
                   <td>member</td>
                   <td>46(j)</td>
               </tr>
               <tr>
                   <td>16</td>
                   <td>mental health nurse: tmt.arunachalam shanthi, staff nurse, institute of mental health, chennai-10</td>
                   <td>member</td>
                   <td>46(k)</td>
               </tr>
               <tr>
                   <td>17</td>
                   <td>persons representing persons wo have or ad mental illness: <br> 1- thiru.r.natarajan, no. 18/20,NSJ homes, venugopalapuram, pallavanthangal, chennai-61 <br>2- ms. h.punitha suresh, no.1-c block, 6th floor,silver apartment,no.24, thanikachalam road, t.nagar, chennai-9</td>
                   <td>members</td>
                   <td>46(i)</td>
               </tr>
               <tr>
                   <td>18</td>
                   <td>persons representing care-givers of persons with mental illness or organizations representing care-givers: <br>
                1-thiru. k.rayappan, new no.4, old no.349/2, anna nagar corss street, thiruvalluvar nagar,ayanavaram, chennai-23 <br>
            2- thiru. e.senthil kumar, no.358/c, 19th cross street, gandhinagar,pallavan salai, chennai-9</td>
            <td>members</td>
            <td>46(m)</td>
               </tr>
               <tr>
                   <td>19</td>
                   <td>persons representing non government organization: <br>
                1- dr.k.v.krishna kumar, director, banyan, 6th main road, mogappair eri scheme, mogappair west, chennai <br>
            2- thiru.m.p.mohamed rafi, founder/trustee, anbagam rehabiliatation center,tirunilai vichur, chennai-103</td>
            <td>members</td>
            <td>46(n)</td>
               </tr>
            </tbody>
        </table>
    </div>
</div>
</div>
 <?php 
 echo'<br>';
 echo'<br>';
 require_once('./php_files/contact_us.php');
 echo'<br>';
 echo'<br>';
 
 require_once('./php_files/footer.php')
 ?>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>