<link rel="stylesheet" href="../css/rulesAndRegulation.css">

<?php  
require_once('./php_files/top_header.php');
require_once('./php_files/nav_header.php');
 ?>

<div class="rulesandregulation">
    <div class="rules">
        <div class="heading"> rules</div>
        <div class="msg">In exercise of the powers conferred by sub-section (2) of section 121 of Mental Healthcare Act, 2017(Central Act 10 of 2017), the Governent of Tamil Nadu is in the process of framing rules and would notify the same after getting  previous approval of the Central Government. </div>
    </div>
    <div class="regulation">
        <div class="heading">regulation</div>
        <div class="msg">In exercise of the powers conferred sub-section (1) of section 123 of Mental Healthcare Act, 2017(Central Act 10 of 2017), Tamil Nadu State Mental Health Authority is framing regulations called Tamil Nadu State Mental Healthcare Regulations, 2020. Framing of these regulations are under active consideration and would soon be notified in the Tamil Nadu Government Gazette.</div>
    </div>
</div>
 

 <?php 
 echo'<br>';
 echo'<br>';
 require_once('./php_files/contact_us.php');
 echo'<br>';
 echo'<br>';
 
 require_once('./php_files/footer.php')
 ?>