<footer>
      <div class="footerCenter">
        <div class="copyright">
          &copy; copyright 2021 TNSMHA. All Rights Reserved
        </div>
        <div class="slMedia">
          <ul>
            <li>
              <a href="#"><i class="fab fa-facebook"></i></a>
            </li>
            <li>
              <a href="#"><i class="fab fa-twitter-square"></i></a>
            </li>
            <li>
              <a href="#"><i class="fab fa-pinterest-square"></i></a>
            </li>
            <li>
              <a href="#"><i class="fab fa-linkedin"></i></a>
            </li>
          </ul>
        </div>
      </div>
    </footer>