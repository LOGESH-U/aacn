
<link rel="stylesheet" href="../css/meetings.css">
<?php
      require_once('./php_files/top_header.php');
      require_once('./php_files/nav_header.php');
?>
<div class="bg">
    <div class="meetingsBody">
        <div class="heading">CONTACT US</div>
<div class="msg">The email service is most suitable for  netizens  who prefer to document their issues in detail rather than phoning in with a query or grievance. The best way to avail the benefit of email services is to send the email directly to TAMIL NADU STATE MENTAL HEALTH AUTHORITY. This would ensure that the concerned person can be ensured with speedy resolution of grievances or feedback as the case may be. The applicable email ID is <a href="mailto:tnsmha@gmail.com">tnsmha@gmail.com</a></div>
<p style="margin-bottom:5rem">Phone Number:</p>

    </div>
    <?php 
 echo'<br>';
 echo'<br>';
 require_once('./php_files/contact_us.php');
 echo'<br>';
 echo'<br>';
 require_once('./php_files/footer.php')
 ?>
</div>

 