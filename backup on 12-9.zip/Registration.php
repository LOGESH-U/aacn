<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>TamilNadu State Mental Health Authority</title>
      <link rel="stylesheet" href="css/style.css" />
      <link rel="stylesheet" href="css/reset.css" />
      <link rel="stylesheet" href="css/variables.css" />
      <link rel="icon" type="image/png" href="images/logo.jpg" />
      <link rel="stylesheet" href="css/Registration.css">
   </head>
   <body>
      <?php
         require_once('./php_files/top_header.php');
         require_once('./php_files/nav_header.php');
      ?>
      <div class="registrationForm">
        <p class="regForm"> Registration form</p>
         <form action="./php_files/registration_upload.php" id="registerFrom" method="POST">
            <div class="container">
               <label for="name">Name</label>
               <input type="text" name="name" value="<?php $name ?>" id="regName" required>
            </div>
            <div class="container">
               <label for="email">Email</label>
               <input type="email" name="email"  value="<?php $email ?>"  id="regMail" required>
            </div>
            <div class="container">
               <label for="phone">Phone</label>
               <input type="tel" name="phone" id="regPhone" pattern="[0-9]{10}" value="<?php $phone ?>" required>
            </div>
            <div class="container">
               <label for="address">Address</label>
               <input type="text" name="address" value="<?php $address ?>" id="regAddress" required>
            </div>
            <div class="container"> 
               <label for="hospitalname">Hospital Name</label>
               <input type="text" value="<?php $hospitalName ?>" name="hospitalName" id="hospitalName" required>
            </div>
            <div class="container">
               <label for="position">Position</label>
               <select name="position" id="position" >
                  <option value="Chairman"> Chairman</option>
                  <option value="Member"> Member</option>
               </select>
            </div>
            <input type="submit" name="submit" id="submit">
         </form>
      </div>
   </body>
</html>